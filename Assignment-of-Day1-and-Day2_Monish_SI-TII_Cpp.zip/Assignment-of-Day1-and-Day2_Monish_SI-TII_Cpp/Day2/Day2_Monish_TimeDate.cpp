//Program for Time and Date Functionalities
//Monish Chunara - Shift I Track II

#include<iostream>
#include<ctime>
using namespace std;

time_t now = time(0);
tm *localTime = localtime(&now);

class Time{
	private:
		int hour,minute,second;

	public:
		void setTime()
		{
			hour = localTime->tm_hour;
			minute = localTime->tm_min;
			second = localTime->tm_sec;
		}

		Time getTime()
		{
			Time t1;
			t1.hour=hour;
			t1.minute=minute;
			t1.second=second;

			return t1;
		}
		
		void setManualTime(int h, int m, int s)
		{
			hour = h;
			minute = m;
			second = s;
		}

		Time sleepTime(Time slept, Time wakeup)
		{
			Time t3;
			t3.hour = wakeup.hour - slept.hour;
			t3.minute = wakeup.minute - slept.minute;
			t3.second = wakeup.second - slept.second;

			//If the time becomes negative, making required corrections
			if(t3.second < 0)
			{
				t3.second = t3.second + 60;
				t3.minute = t3.minute - 1;
			}

			if(t3.minute < 0)
			{
				t3.minute = t3.minute + 60;
				t3.hour = t3.hour - 1;
			}

			if(t3.hour < 0)
			{
				t3.hour = t3.hour + 24;
			}

			return t3;
		}

		void showTime()
		{
			cout << hour << " : " << minute << " : " << second <<endl;
		}

};

class Date{
	public:
		int day,month,year;

		Date setDate()
		{
			Date d1;
			d1.day = localTime->tm_mday;
			d1.month = 1 + localTime->tm_mon;
			d1.year = 1900 + localTime->tm_year;

			return d1;
		}

		Date getDate()
		{
			Date d1;
			d1.day=day;
			d1.month=month;
			d1.year=year;

			return d1;
		}
		
		Date setDoB(int d, int m, int y)
		{
			Date d1;
			d1.day=d;
			d1.month=m;
			d1.year=y;

			return d1;
		}

		void findAge(Date DoB)
		{
			Date current = setDate();

			int ageD,ageM,ageY;
			ageD = current.day - DoB.day;
			ageM = current.month - DoB.month;
			ageY = current.year - DoB.year;

			//If the date becomes negative, making required corrections
			if(ageD < 0)
			{
				ageD = ageD + 30;
				ageM = ageM - 1;
			}

			if(ageM < 0)
			{
				ageM = ageM + 12;
				ageY = ageY - 1;
			}

			cout << "\nAge is : " << ageY << " years " << ageM << " months " << ageD << " Days\n" << endl;
		}

		void showDate()
		{
			cout << day << " / " << month << " / " << year << endl;
		}
};

int main()
{
 Time t1, t2, t3, t4, t5;
 t1.setTime();
 cout << "Current Time is: ";
 t1.showTime();

 //t3 = t3.sleepTime(t1,t2);
 //cout << "\nSleep Time between t1 and t2 is: ";
 //t3.showTime();

 int h,m,s;
 cout << "\nEnter the time at which you slept (24 hr format) hh mm ss: ";
 cin >> h >> m >> s;
 t4.setManualTime(h,m,s);

 //setting time using getTime
 t2 = t1.getTime();

 t5 = t5.sleepTime(t4,t2);
 //Sleep time between current time and slept time
 cout << "\nSleep Time is (hours : minutes : seconds) = ";
 t5.showTime();

 cout << "\n---------------------------------------------------------\n" << endl;
 Date d1, d2, d3;
 d1 = d1.setDate();
 cout << "Current Date is: ";
 d1.showDate();

 //setting date using getDate
 d2 = d1.getDate();
 cout << "\nFor object d2, Date is: ";
 d2.showDate();

 int d,mon,y;
 cout << "\nEnter your Date of Birth (dd mm yyyy): ";
 cin >> d >> mon >> y;
 d3 = d3.setDoB(d,mon,y);

 d3.findAge(d3);
 return 0;
}
