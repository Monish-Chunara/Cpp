//Program to verify the use of Access Specifiers
//Monish Chunara - Shift I Track II

#include<iostream>
using namespace std;

class Calculator
{
	 public:
		int n1=1, n2=2;

		int add_public()
		{
			return n1+n2;
		}

		void multiply_public()
		{
			//accessing a private member function
			cout << n1 <<" * " << n2 << " = " << multiply_private() <<endl;
		}

		void divide_public()
		{
			//accessing a protected member function
			cout << n1 <<" / " << n2 << " = " << divide_protected() <<endl;
		}

		void check_public()
		{
			//accessing private and protected data member
			n3 = 30;
			n4 = 40;
			n5 = 50;
			n6 = 60;
		}

		void display()
		{
			cout << "n1 = " << n1 << "\nn2 = " << n2 << "\nn3 = " << n3 << "\nn4 = " << n4 << "\nn5 = " << n5 << "\nn6 = " << n6 << endl;
		}

	 private:
		int n3, n4;
		int multiply_private()
		{
			return n1*n2;
		}

		void add_private()
		{
			//accessing a public member function add_public
			//and public data members n1 and n2
			cout << n1 <<" + " << n2 << " = " << add_public() <<endl;
		}

		void divide_private()
		{
			//accessing a protected member function divide_protected
			//and public data members n1 and n2
			cout << n1 <<" / " << n2 << " = " << divide_protected() <<endl;
		}

		void check_private()
		{
			//accessing public and protected data member
			n1 = 10;
			n2 = 20;
			n5 = 50;
			n6 = 60;
		}

	 protected:
		int n5, n6;
		int divide_protected()
		{
			return n1/n2;
		}

		void add_protected()
		{
			//accessing a public member function add_public
			//and public data members n1 and n2
			cout << n1 <<" + " << n2 << " = " << add_public() <<endl;
		}

		void multiply_protected()
		{
			//accessing a private member function  multiply_private
			//and public data members n1 and n2
			cout << n1 <<" / " << n2 << " = " << multiply_private() <<endl;
		}

		void check_protected()
		{
			//accessing public and private data member
			n1 = 1;
			n2 = 2;
			n3 = 3;
			n4 = 4;
		}
};

int main()
{
	Calculator cal;
	
	//accessing a public members outside class
	cout << "Addition of " << cal.n1 << " and "<< cal.n2 << " is " << cal.add_public() << endl;

	//accessing private member function from public member function
	cal.multiply_public();

	//accessing protected member function from public member function
	cal.divide_public();

	//accessing private and protected data members from public member function
	cal.check_public();
	cal.display();
	

	/*
	//******Error - private members cannot be accessed outside class********
	//accessing a private members outside class
	cout << "Multiplication of " << cal.n1 << " and "<< cal.n2 << " is " << cal.multiply_private() << endl;

	cout << "n3 = " << cal.n3 << "and n4 = " << cal.n4 << endl;
	cal.check_private();
	*/

	/*
	//******Error - protected members cannot be accessed outside class******
	//accessing a protected members outside class
	cout << "Division of " << cal.n1 << " and "<< cal.n2 << " is " << cal.divide_protected() << endl;

	cout << "n5 = " << cal.n5 << "and n6 = " << cal.n6 << endl;
	cal.check_protected();
	*/

}
